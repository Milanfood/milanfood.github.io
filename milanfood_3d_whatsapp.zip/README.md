# Milan Food — Landing 3D → WhatsApp

Este proyecto es una página ultra ligera con un cubo 3D (CSS/JS) que al hacer clic **abre WhatsApp Web** con mensaje prellenado.

## WhatsApp
- Número: +56 9 3767 9969
- Enlace: https://wa.me/56937679969?text=Hola,%20quisiera%20agendar%20un%20pedido

## Cómo subirlo a GitHub Pages
1. Inicia sesión en tu cuenta **milanfood**.
2. Crea el repo **milanfood.github.io** (público).
3. Sube estos archivos (`index.html` y esta `README.md`).
4. Abre: https://milanfood.github.io

## Editar el mensaje o número
- Abre `index.html` y busca `WA =` o el enlace del botón.
- Reemplaza el número en formato E.164 sin `+` (ej: 56937679969).
- Cambia el texto de `prefill` si quieres.

¡Listo! Escaneas con un QR apuntando a `https://milanfood.github.io`.
